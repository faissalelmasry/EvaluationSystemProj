import { Component, inject, signal } from '@angular/core';
import { AuthService } from '../../core/services/auth';
import { Router } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
})
export class Login {
  private readonly authService=inject(AuthService);
  private readonly router=inject(Router);
  loading=signal(false);
  form=new FormGroup({
    email:new FormControl('',{
      nonNullable:true,  validators: [Validators.required,Validators.email] 
    }),
    password:new FormControl('',{
      nonNullable:true,  validators: [Validators.required]
    })
  });

  onSubmit(){
    if(this.form.invalid){
      return;
    }
    this.loading.set(true);
    this.authService.login(this.form.getRawValue()).subscribe({
      next:(res)=>{
       this.authService.saveToken(res.token);
        this.loading.set(false);
        this.router.navigate(['/departments']);;
      },
      error:(err)=>{
        console.error(err);
        this.loading.set(false);
      }
    })
  }
  logout() {
  this.authService.logout().subscribe({
    next: () => {
      this.authService.clearToken();
      this.router.navigate(['/login']);
    }
  });
}
}
