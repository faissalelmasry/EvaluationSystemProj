export const environment = {
  production: false,
  apiUrl: 'https://localhost:7072/api' 
};